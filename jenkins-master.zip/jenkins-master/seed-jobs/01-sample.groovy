job("sample1-from-seed") {
    steps {
        shell "echo Hello World"
    }
}
